/*
  # Create user with specified credentials

  1. Changes
    - Creates a new user with email 'anthonyyouna@gmail.com' and password 'matrix'
    - Sets the user role to 'client'
    - Associates the user with TD Synnex company

  2. Security
    - Password is properly hashed using bcrypt
    - User is created in both auth.users and public.users tables
*/

DO $$
DECLARE
  new_user_id uuid;
  td_synnex_id uuid;
BEGIN
  -- Get TD Synnex company ID (assuming it exists)
  SELECT id INTO td_synnex_id
  FROM companies
  WHERE name = 'TD Synnex';

  -- Create auth user if not exists
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'anthonyyouna@gmail.com'
  ) THEN
    new_user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin
    )
    VALUES (
      new_user_id,
      '00000000-0000-0000-0000-000000000000',
      'anthonyyouna@gmail.com',
      extensions.crypt('matrix', extensions.gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      false
    );

    -- Create public user
    INSERT INTO public.users (id, email, role, company_id)
    VALUES (new_user_id, 'anthonyyouna@gmail.com', 'client', td_synnex_id);
  ELSE
    -- If user exists, update their password and role
    UPDATE auth.users
    SET encrypted_password = extensions.crypt('matrix', extensions.gen_salt('bf'))
    WHERE email = 'anthonyyouna@gmail.com';

    -- Update public user
    UPDATE public.users
    SET 
      role = 'client',
      company_id = td_synnex_id
    WHERE email = 'anthonyyouna@gmail.com';
  END IF;
END $$;