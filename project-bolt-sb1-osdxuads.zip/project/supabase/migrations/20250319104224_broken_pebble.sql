/*
  # Clean up database data

  1. Data Cleanup
    - Delete all companies except those associated with super admin
    - Delete all jobs
    - Delete all CVs
    - Delete all users except super admin
    
  Note: Due to cascade delete and triggers:
    - Deleting companies will automatically delete associated users
    - Deleting users will clean up auth.users entries
*/

-- Keep only super admin data
DO $$
DECLARE
  super_admin_id uuid;
  super_admin_company_id uuid;
BEGIN
  -- Get super admin user ID
  SELECT id INTO super_admin_id
  FROM users
  WHERE email = 'anthony@consultego.com';

  -- Get super admin's company ID
  SELECT company_id INTO super_admin_company_id
  FROM users
  WHERE id = super_admin_id;

  -- Delete all CVs
  DELETE FROM cvs;

  -- Delete all jobs
  DELETE FROM jobs;

  -- Delete all companies except super admin's company
  DELETE FROM companies
  WHERE id != super_admin_company_id;

  -- Delete all users except super admin
  -- Note: This is technically not needed since company deletion cascade would handle it,
  -- but we include it for completeness
  DELETE FROM users
  WHERE id != super_admin_id;
END $$;