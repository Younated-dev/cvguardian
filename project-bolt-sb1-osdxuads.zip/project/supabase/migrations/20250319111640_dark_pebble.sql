/*
  # Fix user account configuration

  1. Changes
    - Reset user password
    - Ensure user exists in auth.users
    - Ensure user exists in public.users with correct role
    - Set all required metadata and confirmation flags
*/

DO $$
DECLARE
  user_id uuid;
  td_synnex_id uuid;
BEGIN
  -- Get TD Synnex company ID
  SELECT id INTO td_synnex_id
  FROM companies
  WHERE name = 'TD Synnex';

  -- Get or create user ID
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'anthonyyouna@gmail.com';

  IF user_id IS NULL THEN
    -- Create new user if doesn't exist
    user_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      role_id
    )
    VALUES (
      user_id,
      '00000000-0000-0000-0000-000000000000',
      'anthonyyouna@gmail.com',
      extensions.crypt('matrix', extensions.gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      jsonb_build_object(
        'provider', 'email',
        'providers', ARRAY['email'],
        'email_confirmed', true
      ),
      jsonb_build_object(
        'email_confirmed', true
      ),
      false,
      1
    );
  ELSE
    -- Update existing user
    UPDATE auth.users
    SET 
      encrypted_password = extensions.crypt('matrix', extensions.gen_salt('bf')),
      email_confirmed_at = NOW(),
      updated_at = NOW(),
      raw_app_meta_data = jsonb_build_object(
        'provider', 'email',
        'providers', ARRAY['email'],
        'email_confirmed', true
      ),
      raw_user_meta_data = jsonb_build_object(
        'email_confirmed', true
      )
    WHERE id = user_id;
  END IF;

  -- Ensure user exists in public schema with correct role
  INSERT INTO public.users (id, email, role, company_id)
  VALUES (user_id, 'anthonyyouna@gmail.com', 'client', td_synnex_id)
  ON CONFLICT (id) DO UPDATE
  SET 
    role = 'client',
    company_id = td_synnex_id;

END $$;