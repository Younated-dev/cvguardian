/*
  # Fix CVs table RLS policies

  1. Changes
    - Drop existing policies if any
    - Create new policies for admin access
    - Create policies for client access to their company's CVs

  2. Security
    - Enable RLS on cvs table
    - Super admin has full access to all CVs
    - Clients can only view CVs
*/

-- Enable RLS
ALTER TABLE cvs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage all CVs" ON cvs;
DROP POLICY IF EXISTS "Users can view CVs for their company's jobs" ON cvs;

-- Create policy for super admin
CREATE POLICY "Super admin can manage all CVs"
ON cvs
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.email = 'anthony@consultego.com'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.email = 'anthony@consultego.com'
  )
);