/*
  # Fix companies table RLS policies

  1. Changes
    - Drop and recreate RLS policies for companies table
    - Fix admin role check by properly checking user role from users table
    - Add policy for users to view their own company
    - Add policy for admins to manage all companies

  2. Security
    - Enable RLS on companies table
    - Add policies for:
      - Admins can perform all operations (CRUD)
      - Users can only view their own company
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

-- Recreate policies with proper role checks
CREATE POLICY "Admins can manage companies"
ON companies
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  )
);

CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT company_id
    FROM users
    WHERE users.id = auth.uid()
  )
);