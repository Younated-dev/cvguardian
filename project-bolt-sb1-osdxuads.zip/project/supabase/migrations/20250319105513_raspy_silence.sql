/*
  # Update user password

  1. Changes
    - Updates the password for user 'anthonyyouna@gmail.com' to 'matrix'
    
  2. Notes
    - Uses Supabase's built-in encryption function
    - Only affects the specific user
*/

UPDATE auth.users
SET encrypted_password = extensions.crypt('matrix', extensions.gen_salt('bf'))
WHERE email = 'anthonyyouna@gmail.com';