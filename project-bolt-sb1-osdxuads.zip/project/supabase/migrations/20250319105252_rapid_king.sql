/*
  # Create admin user profile

  1. New User
    - Create a new admin user with email anthonyyouna@gmail.com
    - Set password to 'matrix'
    - Assign admin role
    - Create corresponding public user record

  2. Security
    - Password is encrypted using bcrypt
    - User is created with email confirmation
*/

-- Create auth user with a direct insert
WITH new_auth_user AS (
  INSERT INTO auth.users (
    instance_id,
    email,
    encrypted_password,
    email_confirmed_at,
    created_at,
    updated_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    role_id
  )
  VALUES (
    '00000000-0000-0000-0000-000000000000',
    'anthonyyouna@gmail.com',
    extensions.crypt('matrix', extensions.gen_salt('bf')),
    NOW(),
    NOW(),
    NOW(),
    '{"provider":"email","providers":["email"]}',
    '{}',
    true,
    1
  )
  RETURNING id
)
-- Create public user record using the auth user's ID
INSERT INTO public.users (id, email, role)
SELECT 
  id,
  'anthonyyouna@gmail.com',
  'admin'
FROM new_auth_user;