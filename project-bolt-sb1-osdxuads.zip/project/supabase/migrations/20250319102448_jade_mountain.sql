/*
  # Fix companies table RLS policies

  1. Changes
    - Drop and recreate RLS policies for companies table
    - Fix admin role check using proper auth.role() function
    - Add proper policies for company management

  2. Security
    - Enable RLS on companies table
    - Add policies for:
      - Admins to manage all companies
      - Users to view their own company
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

-- Create new policies with correct auth checks
CREATE POLICY "Admins can manage companies"
ON companies
FOR ALL
TO authenticated
USING (auth.role() = 'admin')
WITH CHECK (auth.role() = 'admin');

CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (id IN (
  SELECT company_id 
  FROM users 
  WHERE id = auth.uid()
));