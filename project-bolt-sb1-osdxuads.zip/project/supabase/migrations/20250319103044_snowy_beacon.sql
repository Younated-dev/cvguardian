/*
  # Fix RLS policies and add helper functions

  1. Changes
    - Add helper function to check if user is super admin
    - Add helper function to check if user is admin
    - Update companies policies
    - Update jobs policies
    - Update CVs policies

  2. Security
    - Super admin (anthony@consultego.com) has full access to all resources
    - Company admins can manage their own company's resources
    - Users can view their own company's resources
*/

-- Helper functions
CREATE OR REPLACE FUNCTION is_super_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.email = 'anthony@consultego.com'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Companies policies
DROP POLICY IF EXISTS "Super admin can manage all companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

CREATE POLICY "Super admin can manage all companies"
ON companies
FOR ALL
TO authenticated
USING (is_super_admin())
WITH CHECK (is_super_admin());

CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT company_id
    FROM users
    WHERE users.id = auth.uid()
  )
);

-- Jobs policies
DROP POLICY IF EXISTS "Admins can manage all jobs" ON jobs;
DROP POLICY IF EXISTS "Users can manage their company's jobs" ON jobs;

CREATE POLICY "Super admin can manage all jobs"
ON jobs
FOR ALL
TO authenticated
USING (is_super_admin())
WITH CHECK (is_super_admin());

CREATE POLICY "Users can manage their company's jobs"
ON jobs
FOR ALL
TO authenticated
USING (
  company_id IN (
    SELECT company_id
    FROM users
    WHERE users.id = auth.uid()
  )
)
WITH CHECK (
  company_id IN (
    SELECT company_id
    FROM users
    WHERE users.id = auth.uid()
  )
);

-- CVs policies
DROP POLICY IF EXISTS "Super admin can manage all CVs" ON cvs;

CREATE POLICY "Super admin can manage all CVs"
ON cvs
FOR ALL
TO authenticated
USING (is_super_admin())
WITH CHECK (is_super_admin());