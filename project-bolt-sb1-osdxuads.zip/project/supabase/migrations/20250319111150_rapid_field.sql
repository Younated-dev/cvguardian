/*
  # Activate user account

  1. Changes
    - Set email_confirmed_at to current timestamp for user
    - Ensure user has correct role and company assignment
    - Verify password is set correctly

  2. Security
    - No changes to security policies
*/

DO $$
DECLARE
  user_id uuid;
  td_synnex_id uuid;
BEGIN
  -- Get TD Synnex company ID
  SELECT id INTO td_synnex_id
  FROM companies
  WHERE name = 'TD Synnex';

  -- Get user ID
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'anthonyyouna@gmail.com';

  -- Update auth user
  UPDATE auth.users
  SET 
    email_confirmed_at = NOW(),
    updated_at = NOW()
  WHERE id = user_id;

  -- Ensure user has correct role and company in public schema
  UPDATE public.users
  SET 
    role = 'client',
    company_id = td_synnex_id
  WHERE id = user_id;
END $$;