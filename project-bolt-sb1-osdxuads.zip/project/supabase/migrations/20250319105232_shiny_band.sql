/*
  # Create admin user profile

  1. New User
    - Create a new admin user with email anthonyyouna@gmail.com
    - Set password to 'matrix'
    - Assign admin role
    - Create corresponding public user record

  2. Security
    - Password is encrypted using bcrypt
    - User is created with email confirmation
*/

-- Create auth user
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  role_id
)
VALUES (
  extensions.uuid_generate_v4(),
  '00000000-0000-0000-0000-000000000000',
  'anthonyyouna@gmail.com',
  extensions.crypt('matrix', extensions.gen_salt('bf')),
  NOW(),
  NOW(),
  NOW(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  true,
  1
)
RETURNING id INTO new_user_id;

-- Create public user with admin role
INSERT INTO public.users (id, email, role)
SELECT 
  id,
  'anthonyyouna@gmail.com',
  'admin'
FROM auth.users
WHERE email = 'anthonyyouna@gmail.com';