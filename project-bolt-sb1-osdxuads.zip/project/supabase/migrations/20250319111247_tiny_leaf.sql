/*
  # Fix account activation

  1. Changes
    - Ensure user account is properly activated
    - Set email_confirmed_at timestamp
    - Update user metadata
*/

DO $$
DECLARE
  user_id uuid;
BEGIN
  -- Get user ID
  SELECT id INTO user_id
  FROM auth.users
  WHERE email = 'anthonyyouna@gmail.com';

  -- Update auth user to ensure account is activated
  UPDATE auth.users
  SET 
    email_confirmed_at = NOW(),
    updated_at = NOW(),
    raw_app_meta_data = jsonb_set(
      raw_app_meta_data,
      '{email_confirmed}',
      'true'
    ),
    raw_user_meta_data = jsonb_set(
      raw_user_meta_data,
      '{email_confirmed}',
      'true'
    )
  WHERE id = user_id;

  -- Ensure user exists in public schema with correct role
  UPDATE public.users
  SET role = 'client'
  WHERE id = user_id;
END $$;