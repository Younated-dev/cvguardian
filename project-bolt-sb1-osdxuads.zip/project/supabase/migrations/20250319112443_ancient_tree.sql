/*
  # Add recruiter role and job applications

  1. Changes
    - Update users role check to include 'recruiter'
    - Add job_applications table to link CVs with jobs
    - Add RLS policies for recruiters

  2. New Tables
    - job_applications
      - id (uuid, primary key)
      - job_id (uuid, references jobs)
      - cv_id (uuid, references cvs)
      - status (text)
      - created_at (timestamp)
      - notes (text)

  3. Security
    - Enable RLS on job_applications table
    - Add policies for recruiters and admins
*/

-- Update users role check
ALTER TABLE users
DROP CONSTRAINT users_role_check;

ALTER TABLE users
ADD CONSTRAINT users_role_check 
CHECK (role = ANY (ARRAY['admin'::text, 'client'::text, 'recruiter'::text]));

-- Create job applications table
CREATE TABLE job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  cv_id uuid REFERENCES cvs(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'accepted', 'rejected')),
  notes text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Enable RLS
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Policies for job applications
CREATE POLICY "Recruiters can manage job applications"
  ON job_applications
  FOR ALL
  TO authenticated
  USING (
    (SELECT role FROM users WHERE id = auth.uid()) IN ('recruiter', 'admin')
  )
  WITH CHECK (
    (SELECT role FROM users WHERE id = auth.uid()) IN ('recruiter', 'admin')
  );

-- Update CV policies to allow recruiter access
DROP POLICY IF EXISTS "Super admin can manage all CVs" ON cvs;

CREATE POLICY "Recruiters and admins can manage CVs"
  ON cvs
  FOR ALL
  TO authenticated
  USING (
    (SELECT role FROM users WHERE id = auth.uid()) IN ('recruiter', 'admin')
  )
  WITH CHECK (
    (SELECT role FROM users WHERE id = auth.uid()) IN ('recruiter', 'admin')
  );

-- Function to check if user is recruiter
CREATE OR REPLACE FUNCTION is_recruiter()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role = 'recruiter'
  );
$$;