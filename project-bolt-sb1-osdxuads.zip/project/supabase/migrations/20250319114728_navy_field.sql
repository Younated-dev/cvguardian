/*
  # Fix job applications relationships and policies

  1. Changes
    - Add policy for clients to view applications for their jobs
    - Add policy for recruiters/admins to manage applications
    - Add policy for viewing CVs based on role and ownership
    
  2. Security
    - Ensure clients can only see applications for their company's jobs
    - Allow recruiters/admins to manage all applications
    - Protect CV access based on role and ownership
*/

-- Allow clients to view applications for their jobs
CREATE POLICY "Clients can view applications for their jobs"
ON job_applications
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM jobs
    JOIN users ON users.company_id = jobs.company_id
    WHERE jobs.id = job_applications.job_id
    AND users.id = auth.uid()
    AND users.role = 'client'
  )
);

-- Allow recruiters and admins to manage all applications
CREATE POLICY "Recruiters and admins can manage applications"
ON job_applications
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role IN ('recruiter', 'admin')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role IN ('recruiter', 'admin')
  )
);

-- Update CV access policy
CREATE POLICY "CV access based on role and ownership"
ON cvs
FOR ALL
TO authenticated
USING (
  -- Admins and recruiters can access all CVs
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.role IN ('recruiter', 'admin')
  )
  OR
  -- Clients can access CVs linked to their job applications
  EXISTS (
    SELECT 1 FROM job_applications
    JOIN jobs ON jobs.id = job_applications.job_id
    JOIN users ON users.company_id = jobs.company_id
    WHERE job_applications.cv_id = cvs.id
    AND users.id = auth.uid()
    AND users.role = 'client'
  )
);