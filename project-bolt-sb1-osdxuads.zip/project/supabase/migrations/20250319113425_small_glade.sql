/*
  # Create storage bucket for CV uploads

  1. Storage
    - Create a new public bucket named 'cvs' for storing CV files
    - Enable public access to allow downloading CVs
  
  2. Security
    - Enable RLS on the bucket
    - Add policy for authenticated users to upload CVs
    - Add policy for public access to read CVs
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('cvs', 'cvs', true);

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to upload CVs
CREATE POLICY "Authenticated users can upload CVs"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'cvs'
  AND (LOWER(storage.extension(name)) = 'pdf')
);

-- Allow public access to read CVs
CREATE POLICY "Anyone can read CVs"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'cvs');