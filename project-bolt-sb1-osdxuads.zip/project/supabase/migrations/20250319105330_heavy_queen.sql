/*
  # Link user to TD Synnex company

  1. Changes
    - Update the user record to link it to the TD Synnex company
    
  2. Notes
    - Uses a safe update that only affects the specific user
    - Preserves all other user data
*/

-- Update the user's company_id
UPDATE public.users
SET company_id = (
  SELECT id 
  FROM companies 
  WHERE name = 'TD Synnex'
)
WHERE email = 'anthonyyouna@gmail.com';