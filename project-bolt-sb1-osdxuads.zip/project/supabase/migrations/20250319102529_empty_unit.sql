/*
  # Fix companies table RLS policies

  1. Changes
    - Drop and recreate RLS policies for companies table
    - Fix admin role check by joining with users table
    - Maintain existing policy for users viewing their own company

  2. Security
    - Enable RLS on companies table
    - Add policies for:
      - Admins to manage all companies (using proper role check)
      - Users to view their own company
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

-- Create new policies with correct role check
CREATE POLICY "Admins can manage companies"
ON companies
FOR ALL
TO authenticated
USING (EXISTS (
  SELECT 1 FROM users 
  WHERE users.id = auth.uid() 
  AND users.role = 'admin'
))
WITH CHECK (EXISTS (
  SELECT 1 FROM users 
  WHERE users.id = auth.uid() 
  AND users.role = 'admin'
));

CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (id IN (
  SELECT company_id 
  FROM users 
  WHERE id = auth.uid()
));