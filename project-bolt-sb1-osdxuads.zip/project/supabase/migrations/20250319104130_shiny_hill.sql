/*
  # Add company deletion trigger

  1. New Functions
    - `handle_company_deletion`: Deletes auth users when a company is deleted
    - `delete_auth_user`: Helper function to delete a user from auth.users

  2. New Triggers
    - `company_deletion_trigger`: Triggers when a company is deleted
    
  3. Security
    - Functions are SECURITY DEFINER to run with elevated privileges
    - Only super admin can delete companies (already enforced by RLS)
*/

-- Helper function to delete auth user
CREATE OR REPLACE FUNCTION delete_auth_user(user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM auth.users WHERE id = user_id;
END;
$$;

-- Function to handle company deletion
CREATE OR REPLACE FUNCTION handle_company_deletion()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Delete auth users for all users in the company
  -- Note: The users table entries will be deleted automatically by the FK cascade
  PERFORM delete_auth_user(id)
  FROM users
  WHERE company_id = OLD.id;
  
  RETURN OLD;
END;
$$;

-- Create trigger
CREATE TRIGGER company_deletion_trigger
  BEFORE DELETE
  ON companies
  FOR EACH ROW
  EXECUTE FUNCTION handle_company_deletion();