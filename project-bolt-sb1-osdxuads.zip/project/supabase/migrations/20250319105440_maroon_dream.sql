/*
  # Update user role to client

  1. Changes
    - Changes the role of user 'anthonyyouna@gmail.com' from 'admin' to 'client'
    
  2. Notes
    - Uses a safe update that only affects the specific user
    - Preserves all other user data and company association
*/

UPDATE public.users
SET role = 'client'
WHERE email = 'anthonyyouna@gmail.com';