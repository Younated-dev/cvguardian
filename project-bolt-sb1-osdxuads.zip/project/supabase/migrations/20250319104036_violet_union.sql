/*
  # Add admin user management functions

  1. New Functions
    - `create_client_user`: Creates a new client user with proper auth setup
    - `delete_client_user`: Safely deletes a client user and their auth account

  2. Security
    - Functions are SECURITY DEFINER to run with elevated privileges
    - Only super admin can execute these functions
*/

-- Function to create a new client user
CREATE OR REPLACE FUNCTION create_client_user(
  user_email text,
  company_id uuid
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id uuid;
BEGIN
  -- Check if caller is super admin
  IF NOT is_super_admin() THEN
    RAISE EXCEPTION 'Only super admin can create users';
  END IF;

  -- Create auth user
  new_user_id := extensions.uuid_generate_v4();
  
  INSERT INTO auth.users (
    id,
    email,
    email_confirmed_at,
    created_at,
    updated_at,
    raw_user_meta_data
  )
  VALUES (
    new_user_id,
    user_email,
    NOW(),
    NOW(),
    NOW(),
    jsonb_build_object('role', 'client')
  );

  -- Create user profile
  INSERT INTO public.users (
    id,
    email,
    role,
    company_id
  )
  VALUES (
    new_user_id,
    user_email,
    'client',
    company_id
  );

  RETURN new_user_id;
END;
$$;