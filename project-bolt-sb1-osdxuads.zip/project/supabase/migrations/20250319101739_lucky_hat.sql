/*
  # Create jobs, companies, and CVs tables

  1. New Tables
    - `companies`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `created_at` (timestamp with timezone)
    
    - `jobs`
      - `id` (uuid, primary key)
      - `title` (text, required)
      - `company_id` (uuid, foreign key to companies)
      - `location` (text, required)
      - `salary` (integer)
      - `description` (text)
      - `created_at` (timestamp with timezone)
    
    - `cvs`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `email` (text, required)
      - `position` (text, required)
      - `experience` (integer)
      - `salary` (integer)
      - `file_url` (text)
      - `created_at` (timestamp with timezone)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users based on role
*/

-- Companies table
CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage companies"
  ON companies
  USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Users can view their own company"
  ON companies
  FOR SELECT
  USING (id = (SELECT company_id FROM users WHERE id = auth.uid()));

-- Jobs table
CREATE TABLE jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE,
  location text NOT NULL,
  salary integer,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage all jobs"
  ON jobs
  USING (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Users can manage their company's jobs"
  ON jobs
  USING (company_id = (SELECT company_id FROM users WHERE id = auth.uid()));

-- CVs table
CREATE TABLE cvs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  position text NOT NULL,
  experience integer,
  salary integer,
  file_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cvs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage all CVs"
  ON cvs
  USING (auth.jwt() ->> 'role' = 'admin');

-- Add company_id to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS company_id uuid REFERENCES companies(id) ON DELETE CASCADE;