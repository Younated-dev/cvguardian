/*
  # Create user in auth and public tables

  1. Changes
    - Create user in auth.users table
    - Create corresponding user in public.users table
    - Link user to TD Synnex company
    - Set role as client
    - Set password

  2. Security
    - Uses secure password hashing
    - Maintains referential integrity
*/

-- First, create the user in auth.users if they don't exist
DO $$
DECLARE
  new_user_id uuid;
  td_synnex_id uuid;
BEGIN
  -- Get TD Synnex company ID
  SELECT id INTO td_synnex_id
  FROM companies
  WHERE name = 'TD Synnex';

  -- Create auth user if not exists
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'anthonyyouna@gmail.com'
  ) THEN
    new_user_id := extensions.uuid_generate_v4();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin
    )
    VALUES (
      new_user_id,
      '00000000-0000-0000-0000-000000000000',
      'anthonyyouna@gmail.com',
      extensions.crypt('matrix', extensions.gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      false
    );

    -- Create public user
    INSERT INTO public.users (id, email, role, company_id)
    VALUES (new_user_id, 'anthonyyouna@gmail.com', 'client', td_synnex_id);
  ELSE
    -- If user exists, update their role and company
    UPDATE public.users
    SET 
      role = 'client',
      company_id = td_synnex_id
    WHERE email = 'anthonyyouna@gmail.com';
  END IF;
END $$;