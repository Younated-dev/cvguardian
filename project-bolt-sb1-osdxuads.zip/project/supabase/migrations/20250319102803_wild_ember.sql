/*
  # Fix companies table RLS policies for super admin

  1. Changes
    - Drop existing policies
    - Create new policy for super admin (anthony@consultego.com) to manage all companies
    - Keep policy for users to view their own company

  2. Security
    - Enable RLS on companies table
    - Super admin has full access to all companies
    - Regular users can only view their own company
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

-- Create policy for super admin
CREATE POLICY "Super admin can manage all companies"
ON companies
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.email = 'anthony@consultego.com'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users
    WHERE users.id = auth.uid()
    AND users.email = 'anthony@consultego.com'
  )
);

-- Keep policy for users to view their own company
CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT company_id
    FROM users
    WHERE users.id = auth.uid()
  )
);