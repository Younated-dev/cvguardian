/*
  # Update create_client_user procedure
  
  1. Changes
    - Add email existence check before creating user
    - Return helpful error message if email exists
    - Improve error handling
*/

CREATE OR REPLACE FUNCTION create_client_user(user_email text, company_id uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id uuid;
  result json;
BEGIN
  -- Check if email already exists in auth.users
  IF EXISTS (
    SELECT 1 FROM auth.users WHERE email = user_email
  ) THEN
    RAISE EXCEPTION 'Email already exists' USING HINT = 'Please use a different email address';
  END IF;

  -- Create auth user
  new_user_id := extensions.uuid_generate_v4();
  
  INSERT INTO auth.users (
    id,
    instance_id,
    email,
    encrypted_password,
    email_confirmed_at,
    created_at,
    updated_at,
    raw_app_meta_data,
    raw_user_meta_data,
    is_super_admin,
    role_id
  )
  VALUES (
    new_user_id,
    '00000000-0000-0000-0000-000000000000',
    user_email,
    extensions.crypt('temporary123', extensions.gen_salt('bf')),
    NOW(),
    NOW(),
    NOW(),
    '{"provider":"email","providers":["email"]}',
    '{}',
    false,
    1
  );

  -- Create public user
  INSERT INTO public.users (id, email, role, company_id)
  VALUES (new_user_id, user_email, 'client', company_id);

  -- Return success result
  result := json_build_object(
    'id', new_user_id,
    'email', user_email,
    'company_id', company_id
  );

  RETURN result;
EXCEPTION
  WHEN others THEN
    -- Return error result
    result := json_build_object(
      'error', SQLERRM,
      'detail', SQLSTATE
    );
    RETURN result;
END;
$$;