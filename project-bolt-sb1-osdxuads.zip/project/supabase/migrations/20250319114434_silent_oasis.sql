/*
  # Fix job applications created_by field

  1. Changes
    - Make created_by NOT NULL
    - Add default value to use the authenticated user's ID
    - Add RLS policy for user creation
    
  2. Security
    - Add policy to ensure users can only create applications with their own ID
*/

-- Make created_by NOT NULL
ALTER TABLE job_applications 
  ALTER COLUMN created_by SET NOT NULL;

-- Add default value for created_by
ALTER TABLE job_applications
  ALTER COLUMN created_by 
  SET DEFAULT auth.uid();

-- Add RLS policy for application creation
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'job_applications' 
    AND policyname = 'Users can only create applications as themselves'
  ) THEN
    CREATE POLICY "Users can only create applications as themselves"
    ON job_applications
    FOR INSERT
    TO authenticated
    WITH CHECK (
      created_by = auth.uid()
    );
  END IF;
END $$;