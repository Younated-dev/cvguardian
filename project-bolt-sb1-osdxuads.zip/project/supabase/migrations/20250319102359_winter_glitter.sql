/*
  # Fix RLS policies for companies table

  1. Changes
    - Update RLS policy for companies table to allow admins to manage companies
    - Fix policy syntax to use proper auth functions

  2. Security
    - Enable RLS on companies table
    - Add policy for admins to manage companies using proper auth checks
    - Add policy for users to view their own company
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can manage companies" ON companies;
DROP POLICY IF EXISTS "Users can view their own company" ON companies;

-- Create new policies with correct auth checks
CREATE POLICY "Admins can manage companies"
ON companies
FOR ALL
TO authenticated
USING (auth.jwt() ->> 'role' = 'admin')
WITH CHECK (auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Users can view their own company"
ON companies
FOR SELECT
TO authenticated
USING (id IN (
  SELECT company_id 
  FROM users 
  WHERE id = auth.uid()
));