/*
  # Create super admin user

  1. Changes
    - Creates super admin user in auth.users if not exists
    - Creates corresponding entry in public.users
    - Creates company for super admin if not exists
    - Sets up proper role and company association

  2. Security
    - Uses secure password hashing
    - Maintains referential integrity
*/

-- Create the super admin user and company
DO $$
DECLARE
  super_admin_id uuid;
  company_id uuid;
BEGIN
  -- First create the company if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM companies WHERE name = 'Consultego'
  ) THEN
    INSERT INTO companies (id, name)
    VALUES (gen_random_uuid(), 'Consultego')
    RETURNING id INTO company_id;
  ELSE
    SELECT id INTO company_id
    FROM companies
    WHERE name = 'Consultego';
  END IF;

  -- Create auth user if not exists
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'anthony@consultego.com'
  ) THEN
    super_admin_id := gen_random_uuid();
    
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin
    )
    VALUES (
      super_admin_id,
      '00000000-0000-0000-0000-000000000000',
      'anthony@consultego.com',
      extensions.crypt('admin123', extensions.gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      true
    );

    -- Create public user
    INSERT INTO public.users (id, email, role, company_id)
    VALUES (super_admin_id, 'anthony@consultego.com', 'admin', company_id);
  ELSE
    -- If user exists, ensure they have the correct role and company
    SELECT id INTO super_admin_id
    FROM auth.users
    WHERE email = 'anthony@consultego.com';

    -- Update public user if exists, create if not
    INSERT INTO public.users (id, email, role, company_id)
    VALUES (super_admin_id, 'anthony@consultego.com', 'admin', company_id)
    ON CONFLICT (id) DO UPDATE
    SET role = 'admin',
        company_id = EXCLUDED.company_id;
  END IF;
END $$;