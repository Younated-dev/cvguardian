/*
  # Add application status field

  1. Changes
    - Add status field to job_applications table with allowed values:
      - 'pending' (default)
      - 'reviewing'
      - 'accepted'
      - 'rejected'
    - Add check constraint to ensure only valid statuses are used
    - Set default value to 'pending'

  2. Security
    - No changes to RLS policies needed as existing policies cover status field access
*/

-- Add status field with check constraint
ALTER TABLE job_applications
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending'
  CHECK (status IN ('pending', 'reviewing', 'accepted', 'rejected'));

-- Update existing rows to have status 'pending' if null
UPDATE job_applications 
SET status = 'pending' 
WHERE status IS NULL;