/*
  # Fix job applications created_by field

  1. Changes
    - Make created_by NOT NULL to ensure it's always set
    - Add foreign key constraint to auth.users
    - Add default value to use the authenticated user's ID
    
  2. Security
    - Update RLS policy to ensure users can only create applications with their own ID
*/

-- Make created_by NOT NULL and add foreign key constraint
ALTER TABLE job_applications 
  ALTER COLUMN created_by SET NOT NULL,
  ADD CONSTRAINT job_applications_created_by_fkey 
    FOREIGN KEY (created_by) 
    REFERENCES auth.users(id) 
    ON DELETE CASCADE;

-- Add default value for created_by
ALTER TABLE job_applications
  ALTER COLUMN created_by 
  SET DEFAULT auth.uid();

-- Update RLS policy to ensure users can only create applications with their own ID
CREATE POLICY "Users can only create applications as themselves"
ON job_applications
FOR INSERT
TO authenticated
WITH CHECK (
  created_by = auth.uid()
);