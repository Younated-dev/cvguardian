import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { LayoutDashboard, Building2, Briefcase, FileText } from 'lucide-react';
import AdminDashboard from './pages/admin/Dashboard';
import AdminJobs from './pages/admin/Jobs';
import AdminClients from './pages/admin/Clients';
import AdminCVs from './pages/admin/CVs';
import RecruiterDashboard from './pages/recruiter/Dashboard';
import RecruiterJobs from './pages/recruiter/Jobs';
import RecruiterCVs from './pages/recruiter/CVs';
import ClientDashboard from './pages/client/Dashboard';
import ClientJobs from './pages/client/Jobs';
import ClientCVs from './pages/client/CVs';
import Login from './pages/auth/Login';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './contexts/AuthContext';

const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode; allowedRoles: ('admin' | 'client' | 'recruiter')[] }) => {
  const { user, userRole } = useAuth();
  
  if (!user || !userRole || !allowedRoles.includes(userRole)) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

const navigation = {
  admin: [
    { name: 'Tableau de bord', path: '/admin', icon: LayoutDashboard },
    { name: 'Offres', path: '/admin/jobs', icon: Briefcase },
    { name: 'Clients', path: '/admin/clients', icon: Building2 },
    { name: 'CVs', path: '/admin/cvs', icon: FileText },
  ],
  client: [
    { name: 'Tableau de bord', path: '/client', icon: LayoutDashboard },
    { name: 'Offres', path: '/client/jobs', icon: Briefcase },
    { name: 'CVs', path: '/client/cvs', icon: FileText },
  ],
  recruiter: [
    { name: 'Tableau de bord', path: '/recruiter', icon: LayoutDashboard },
    { name: 'Offres', path: '/recruiter/jobs', icon: Briefcase },
    { name: 'CVs', path: '/recruiter/cvs', icon: FileText },
  ],
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          {/* Admin Routes */}
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout navigation={navigation.admin}>
                  <AdminDashboard />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/jobs"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout navigation={navigation.admin}>
                  <AdminJobs />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/clients"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout navigation={navigation.admin}>
                  <AdminClients />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/cvs"
            element={
              <ProtectedRoute allowedRoles={['admin']}>
                <Layout navigation={navigation.admin}>
                  <AdminCVs />
                </Layout>
              </ProtectedRoute>
            }
          />
          
          {/* Client Routes */}
          <Route
            path="/client"
            element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout navigation={navigation.client}>
                  <ClientDashboard />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/client/jobs"
            element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout navigation={navigation.client}>
                  <ClientJobs />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/client/cvs"
            element={
              <ProtectedRoute allowedRoles={['client']}>
                <Layout navigation={navigation.client}>
                  <ClientCVs />
                </Layout>
              </ProtectedRoute>
            }
          />
          
          {/* Recruiter Routes */}
          <Route
            path="/recruiter"
            element={
              <ProtectedRoute allowedRoles={['recruiter', 'admin']}>
                <Layout navigation={navigation.recruiter}>
                  <RecruiterDashboard />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/recruiter/jobs"
            element={
              <ProtectedRoute allowedRoles={['recruiter', 'admin']}>
                <Layout navigation={navigation.recruiter}>
                  <RecruiterJobs />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/recruiter/cvs"
            element={
              <ProtectedRoute allowedRoles={['recruiter', 'admin']}>
                <Layout navigation={navigation.recruiter}>
                  <RecruiterCVs />
                </Layout>
              </ProtectedRoute>
            }
          />
          
          {/* Default redirect */}
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
        <Toaster position="top-right" />
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
