import React, { useState, useEffect } from 'react';
import { Eye, Send } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { getJobs, getCVs, createJobApplication, updateJobApplication } from '../../lib/api';

interface Job {
  id: string;
  title: string;
  company_id: string;
  location: string;
  salary: number;
  description: string;
  created_at: string;
  companies: {
    name: string;
  };
}

interface CV {
  id: string;
  name: string;
  email: string;
  position: string;
  experience: number;
  salary: number;
  file_url?: string;
}

const RecruiterJobs: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [cvs, setCVs] = useState<CV[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCV, setSelectedCV] = useState<string>('');
  const [newCV, setNewCV] = useState(false);
  const [notes, setNotes] = useState('');
  const [isUpdatingApplication, setIsUpdatingApplication] = useState(false);

  useEffect(() => {
    fetchJobs();
    fetchCVs();
  }, []);

  const fetchJobs = async () => {
    try {
      const data = await getJobs();
      setJobs(data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      toast.error('Failed to load jobs');
    }
  };

  const fetchCVs = async () => {
    try {
      const data = await getCVs();
      setCVs(data);
    } catch (error) {
      console.error('Error fetching CVs:', error);
      toast.error('Failed to load CVs');
    }
  };

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJob) return;
    
    setIsLoading(true);
    try {
      if (newCV) {
        // Handle new CV upload
        toast.error('CV upload not implemented yet');
        return;
      }

      await createJobApplication({
        job_id: selectedJob.id,
        cv_id: selectedCV,
        notes,
      });

      toast.success('Application submitted successfully');
      handleClose();
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Failed to submit application');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setSelectedJob(null);
    setSelectedCV('');
    setNewCV(false);
    setNotes('');
  };

  const handleUpdateStatus = async (applicationId: string, status: 'accepted' | 'rejected') => {
    setIsUpdatingApplication(true);
    try {
      await updateJobApplication(applicationId, { status });
      toast.success(`Candidature ${status === 'accepted' ? 'acceptée' : 'refusée'}`);
      await fetchJobs(); // Refresh jobs to update the application status
    } catch (error) {
      console.error('Error updating application status:', error);
      toast.error('Impossible de mettre à jour le statut');
    } finally {
      setIsUpdatingApplication(false);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-medium text-gray-900">Offres d'emploi disponibles</h3>
      </div>

      <div className="mt-8 flow-root">
        <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
            <table className="min-w-full divide-y divide-gray-300">
              <thead>
                <tr>
                  <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Poste</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Entreprise</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Localisation</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Salaire</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr key={job.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">{job.title}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.companies?.name}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.location}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.salary.toLocaleString()}€</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {new Date(job.created_at).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      <div className="flex space-x-2">
                        <button onClick={() => {
                          setSelectedJob(job);
                          setIsModalOpen(true);
                        }} className="text-indigo-600 hover:text-indigo-800">
                          <Send className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={handleClose}
        title="Postuler à l'offre"
      >
        <form onSubmit={handleApply} className="space-y-4">
          <div>
            <h4 className="font-medium text-gray-900">{selectedJob?.title}</h4>
            <p className="text-sm text-gray-500">{selectedJob?.companies?.name} - {selectedJob?.location}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              CV
            </label>
            <div className="mt-2 space-y-2">
              <div className="flex items-center">
                <input
                  type="radio"
                  name="cv-choice"
                  id="existing-cv"
                  checked={!newCV}
                  onChange={() => setNewCV(false)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="existing-cv" className="ml-2 block text-sm text-gray-900">
                  Sélectionner un CV existant
                </label>
              </div>
              {!newCV && (
                <select
                  value={selectedCV}
                  onChange={(e) => setSelectedCV(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                >
                  <option value="">Sélectionner un CV</option>
                  {cvs.map((cv) => (
                    <option key={cv.id} value={cv.id}>
                      {cv.name} - {cv.position}
                    </option>
                  ))}
                </select>
              )}

              <div className="flex items-center">
                <input
                  type="radio"
                  name="cv-choice"
                  id="new-cv"
                  checked={newCV}
                  onChange={() => setNewCV(true)}
                  className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                />
                <label htmlFor="new-cv" className="ml-2 block text-sm text-gray-900">
                  Ajouter un nouveau CV
                </label>
              </div>
              {newCV && (
                <div className="mt-2">
                  <input
                    type="file"
                    accept=".pdf"
                    className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                  />
                </div>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
              Notes
            </label>
            <textarea
              id="notes"
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ajoutez des notes concernant cette candidature..."
            />
          </div>

          <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={handleClose}
              className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading || (!selectedCV && !newCV)}
              className="inline-flex justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 disabled:opacity-50"
            >
              {isLoading ? 'Envoi...' : 'Postuler'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default RecruiterJobs;