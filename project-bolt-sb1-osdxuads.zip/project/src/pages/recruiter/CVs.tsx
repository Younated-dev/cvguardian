import React from 'react';
import AdminCVs from '../admin/CVs';

const RecruiterCVs: React.FC = () => {
  // Reuse the admin CVs component since recruiters have the same CV management capabilities
  return <AdminCVs />;
};

export default RecruiterCVs;