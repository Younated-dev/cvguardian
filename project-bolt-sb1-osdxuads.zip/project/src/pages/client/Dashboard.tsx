import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, FileText, Users } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { getCompanyJobs, getJobApplications } from '../../lib/api';

interface DashboardStats {
  activeJobs: number;
  receivedCVs: number;
  activeApplications: number;
}

const ClientDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    activeJobs: 0,
    receivedCVs: 0,
    activeApplications: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user?.id) {
      fetchStats();
    }
  }, [user?.id]);

  const fetchStats = async () => {
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('company_id')
        .eq('id', user?.id)
        .single();

      if (!userData?.company_id) return;

      const jobs = await getCompanyJobs(userData.company_id);
      const applications = await getJobApplications();
      
      const companyApplications = applications.filter(app => 
        jobs.some(job => job.id === app.job_id)
      );

      setStats({
        activeJobs: jobs.length,
        receivedCVs: companyApplications.length,
        activeApplications: companyApplications.filter(app => 
          app.status === 'pending' || app.status === 'reviewing'
        ).length
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900">Tableau de bord client</h3>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Briefcase className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Offres actives</dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {isLoading ? '...' : stats.activeJobs}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/client/jobs" className="font-medium text-indigo-600 hover:text-indigo-900">Gérer mes offres</Link>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">CVs reçus</dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {isLoading ? '...' : stats.receivedCVs}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/client/cvs" className="font-medium text-indigo-600 hover:text-indigo-900">Voir les CVs</Link>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Candidats en cours</dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {isLoading ? '...' : stats.activeApplications}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link to="/client/cvs" className="font-medium text-indigo-600 hover:text-indigo-900">Voir les candidats</Link>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Activité récente</h3>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            <li className="px-4 py-4 sm:px-6 text-center text-gray-500">
              Pas d'activité pour le moment
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;