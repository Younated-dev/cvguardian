import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Eye, Download, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { getCVs, getCompanyJobs, getJobApplications, updateJobApplication } from '../../lib/api';
import Modal from '../../components/Modal';

interface CV {
  id: string;
  name: string;
  email: string;
  position: string;
  experience: number;
  salary: number;
  file_url?: string;
  created_at: string;
}

interface JobApplication {
  id: string;
  status: string;
  created_at: string;
  notes?: string;
  jobs: {
    id: string;
    title: string;
  };
  cvs: {
    id: string;
    name: string;
    email: string;
    position: string;
  };
}

const ClientCVs: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'applications' | 'cvs'>('applications');
  const [searchParams] = useSearchParams();
  const jobId = searchParams.get('job');
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [cvs, setCVs] = useState<CV[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<JobApplication | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user?.id]);

  const fetchData = async () => {
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('company_id')
        .eq('id', user?.id)
        .single();

      if (!userData?.company_id) {
        toast.error('Aucune entreprise associée à votre compte');
        return;
      }

      const [allCVs, jobs, allApplications] = await Promise.all([
        getCVs(),
        getCompanyJobs(userData.company_id),
        getJobApplications()
      ]);

      // Filter applications for company's jobs
      const companyApplications = allApplications.filter(app =>
        jobs.some(job => job.id === app.job_id)
      );
      
      // If jobId is provided, filter applications for that specific job
      const filteredApplications = jobId
        ? companyApplications.filter(app => app.jobs.id === jobId)
        : companyApplications;

      setApplications(filteredApplications);
      setCVs(allCVs);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Impossible de charger les données');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStatus = async (status: 'accepted' | 'rejected') => {
    if (!selectedApplication) return;
    setIsUpdating(true);

    try {
      await updateJobApplication(selectedApplication.id, { status });
      await fetchData();
      toast.success(`Candidature ${status === 'accepted' ? 'acceptée' : 'refusée'}`);
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error updating application:', error);
      toast.error('Impossible de mettre à jour la candidature');
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'reviewing':
        return 'bg-blue-100 text-blue-800';
      case 'accepted':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'reviewing':
        return 'En cours';
      case 'accepted':
        return 'Accepté';
      case 'rejected':
        return 'Refusé';
      default:
        return status;
    }
  };

  return (
    <div>
      {jobId && (
        <div className="mb-6 p-4 bg-indigo-50 rounded-lg">
          <h2 className="text-lg font-medium text-indigo-900">
            Candidatures pour l'offre : {applications[0]?.jobs.title || 'Chargement...'}
          </h2>
        </div>
      )}

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('applications')}
            className={`${
              activeTab === 'applications'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Candidatures reçues
          </button>
          <button
            onClick={() => setActiveTab('cvs')}
            className={`${
              activeTab === 'cvs'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            CVs disponibles
          </button>
        </nav>
      </div>

      {isLoading ? (
        <div className="mt-8 text-center text-gray-500">Chargement...</div>
      ) : activeTab === 'applications' ? (
        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Candidat</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Poste</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Statut</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {applications.map((application) => (
                    <tr key={application.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm">
                        <div className="font-medium text-gray-900">{application.cvs.name}</div>
                        <div className="text-gray-500">{application.cvs.email}</div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{application.jobs.title}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(application.status)}`}>
                          {getStatusLabel(application.status)}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {new Date(application.created_at).toLocaleDateString('fr-FR')}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500 flex space-x-2">
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => {
                              setSelectedApplication(application);
                              setIsModalOpen(true);
                            }}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Eye className="h-5 w-5" />
                          </button>
                          {application.cvs.file_url && (
                            <a
                              href={application.cvs.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-green-600 hover:text-green-800"
                            >
                              <Download className="h-5 w-5" />
                            </a>
                          )}
                          {application.status === 'pending' && (
                            <>
                              <button
                                onClick={() => handleUpdateStatus('accepted')}
                                className="text-green-600 hover:text-green-800"
                              >
                                <CheckCircle className="h-5 w-5" />
                              </button>
                              <button
                                onClick={() => handleUpdateStatus('rejected')}
                                className="text-red-600 hover:text-red-800"
                              >
                                <XCircle className="h-5 w-5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-8 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Candidat</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Poste recherché</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Expérience</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Prétention</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {cvs.map((cv) => (
                    <tr key={cv.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm">
                        <div className="font-medium text-gray-900">{cv.name}</div>
                        <div className="text-gray-500">{cv.email}</div>
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.position}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.experience} ans</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.salary.toLocaleString()}€</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {new Date(cv.created_at).toLocaleDateString('fr-FR')}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button className="text-blue-600 hover:text-blue-800">
                            <Eye className="h-5 w-5" />
                          </button>
                          {cv.file_url && (
                            <a
                              href={cv.file_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-green-600 hover:text-green-800"
                            >
                              <Download className="h-5 w-5" />
                            </a>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Détails de la candidature"
      >
        {selectedApplication && (
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900">{selectedApplication.cvs.name}</h4>
              <p className="text-sm text-gray-500">{selectedApplication.cvs.email}</p>
            </div>
            <div>
              <h5 className="text-sm font-medium text-gray-700">Poste</h5>
              <p className="text-sm text-gray-900">{selectedApplication.jobs.title}</p>
            </div>
            <div>
              <h5 className="text-sm font-medium text-gray-700">Statut</h5>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(selectedApplication.status)}`}>
                {getStatusLabel(selectedApplication.status)}
              </span>
            </div>
            {selectedApplication.notes && (
              <div>
                <h5 className="text-sm font-medium text-gray-700">Notes</h5>
                <p className="text-sm text-gray-900">{selectedApplication.notes}</p>
              </div>
            )}
            {selectedApplication.status === 'pending' && (
              <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => handleUpdateStatus('rejected')}
                  disabled={isUpdating}
                  className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
                >
                  Refuser
                </button>
                <button
                  onClick={() => handleUpdateStatus('accepted')}
                  disabled={isUpdating}
                  className="inline-flex justify-center rounded-md border border-transparent bg-green-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-green-700"
                >
                  Accepter
                </button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ClientCVs;