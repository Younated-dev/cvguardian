import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Eye } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Modal from '../../components/Modal';
import { getJobs, createJob, updateJob, deleteJob, getCompanies } from '../../lib/api';

interface Job {
  id: string;
  title: string;
  company_id: string;
  location: string;
  salary: number;
  description: string;
  created_at: string;
  companies: {
    name: string;
  };
}

const AdminJobs: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [modalMode, setModalMode] = useState<'create' | 'edit' | 'view' | 'delete'>('create');
  const [isLoading, setIsLoading] = useState(false);
  const [companies, setCompanies] = useState<Array<{ id: string; name: string }>>([]);

  useEffect(() => {
    fetchJobs();
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const data = await getCompanies();
      setCompanies(data);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast.error('Failed to load companies');
    }
  };

  const fetchJobs = async () => {
    try {
      const data = await getJobs();
      setJobs(data);
    } catch (error) {
      console.error('Error fetching jobs:', error);
      toast.error('Failed to load jobs');
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const form = e.currentTarget;
    const formData = new FormData(form);
    const jobData = {
      title: formData.get('title') as string,
      company_id: formData.get('company_id') as string,
      location: formData.get('location') as string,
      salary: parseInt(formData.get('salary') as string),
      description: formData.get('description') as string,
    };

    if (!jobData.company_id || !jobData.title || !jobData.location || !jobData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      if (modalMode === 'edit' && selectedJob) {
        await updateJob(selectedJob.id, jobData);
        toast.success('Job updated successfully');
      } else {
        await createJob(jobData);
        toast.success('Job created successfully');
      }
      await fetchJobs();
      handleClose();
    } catch (error) {
      console.error('Error saving job:', error);
      toast.error('Failed to save job');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedJob) return;
    setIsLoading(true);

    try {
      await deleteJob(selectedJob.id);
      toast.success('Job deleted successfully');
      await fetchJobs();
      handleClose();
    } catch (error) {
      console.error('Error deleting job:', error);
      toast.error('Failed to delete job');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = (job: Job, mode: 'edit' | 'view' | 'delete') => {
    setSelectedJob(job);
    setModalMode(mode);
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setSelectedJob(null);
    setModalMode('create');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-medium text-gray-900">Gestion des offres</h3>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Nouvelle offre
        </button>
      </div>

      <div className="mt-8 flow-root">
        <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
            <table className="min-w-full divide-y divide-gray-300">
              <thead>
                <tr>
                  <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Poste</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Entreprise</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Localisation</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Salaire</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {jobs.map((job) => (
                  <tr key={job.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">{job.title}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.companies?.name}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.location}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{job.salary.toLocaleString()}€</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {new Date(job.created_at).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      <div className="flex space-x-2">
                        <button onClick={() => handleAction(job, 'view')} className="text-blue-600 hover:text-blue-800">
                          <Eye className="h-5 w-5" />
                        </button>
                        <button onClick={() => handleAction(job, 'edit')} className="text-amber-600 hover:text-amber-800">
                          <Pencil className="h-5 w-5" />
                        </button>
                        <button onClick={() => handleAction(job, 'delete')} className="text-red-600 hover:text-red-800">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={handleClose}
        title={
          modalMode === 'create' ? "Ajouter une nouvelle offre" :
          modalMode === 'edit' ? "Modifier l'offre" :
          modalMode === 'view' ? "Détails de l'offre" :
          "Supprimer l'offre"
        }
      >
        {modalMode === 'delete' ? (
          <div className="space-y-4">
            <p className="text-sm text-gray-500">
              Êtes-vous sûr de vouloir supprimer cette offre ? Cette action est irréversible.
            </p>
            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                disabled={isLoading}
                className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
              >
                {isLoading ? 'Suppression...' : 'Supprimer'}
              </button>
            </div>
          </div>
        ) : modalMode === 'view' ? (
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900">{selectedJob?.title}</h4>
              <p className="text-sm text-gray-500">{selectedJob?.companies?.name} - {selectedJob?.location}</p>
            </div>
            <div className="prose prose-sm max-w-none text-gray-500">
              {selectedJob?.description}
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Titre du poste
              </label>
              <input
                type="text"
                name="title"
                id="title"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedJob?.title}
                placeholder="ex: Développeur Full Stack"
              />
            </div>

            <div>
              <label htmlFor="company_id" className="block text-sm font-medium text-gray-700">
                Entreprise
              </label>
              <select
                id="company_id"
                name="company_id"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedJob?.company_id}
              >
                <option value="">Sélectionner une entreprise</option>
                {companies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700">
                Localisation
              </label>
              <input
                type="text"
                name="location"
                id="location"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedJob?.location}
                placeholder="ex: Paris"
              />
            </div>

            <div>
              <label htmlFor="salary" className="block text-sm font-medium text-gray-700">
                Salaire
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <input
                  type="number"
                  name="salary"
                  id="salary"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                  defaultValue={selectedJob?.salary}
                  placeholder="ex: 45000"
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">€</span>
                </div>
              </div>
              <p className="mt-1 text-sm text-gray-500">Salaire annuel brut en euros</p>
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                id="description"
                name="description"
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedJob?.description}
                placeholder="Description détaillée du poste..."
              />
            </div>

            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex justify-center rounded-md border border-transparent bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700"
              >
                {isLoading ? "Enregistrement..." : modalMode === 'edit' ? "Modifier" : "Créer"}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default AdminJobs;