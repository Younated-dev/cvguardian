import React, { useState, useEffect } from 'react';
import { Plus, Pencil, Trash2, Eye } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Modal from '../../components/Modal';
import { getCVs, createCV, updateCV, deleteCV } from '../../lib/api';

interface CV {
  id: string;
  name: string;
  email: string;
  position: string;
  experience: number;
  salary: number;
  file_url?: string;
  created_at: string;
}

const AdminCVs: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [cvs, setCVs] = useState<CV[]>([]);
  const [selectedCV, setSelectedCV] = useState<CV | null>(null);
  const [modalMode, setModalMode] = useState<'create' | 'edit' | 'view' | 'delete'>('create');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchCVs();
  }, []);

  const fetchCVs = async () => {
    try {
      const data = await getCVs();
      setCVs(data);
    } catch (error) {
      console.error('Error fetching CVs:', error);
      toast.error('Failed to load CVs');
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const form = e.currentTarget;
    const formData = new FormData(form);
    const cvData = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      position: formData.get('position') as string,
      experience: parseInt(formData.get('experience') as string),
      salary: parseInt(formData.get('salary') as string),
      file_url: selectedCV?.file_url
    };

    try {
      if (modalMode === 'edit' && selectedCV) {
        await updateCV(selectedCV.id, cvData);
        toast.success('CV updated successfully');
      } else {
        await createCV(cvData);
        toast.success('CV created successfully');
      }
      await fetchCVs();
      handleClose();
    } catch (error) {
      console.error('Error saving CV:', error);
      toast.error('Failed to save CV');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedCV) return;
    setIsLoading(true);

    try {
      await deleteCV(selectedCV.id);
      toast.success('CV deleted successfully');
      await fetchCVs();
      handleClose();
    } catch (error) {
      console.error('Error deleting CV:', error);
      toast.error('Failed to delete CV');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAction = (cv: CV, mode: 'edit' | 'view' | 'delete') => {
    setSelectedCV(cv);
    setModalMode(mode);
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setSelectedCV(null);
    setModalMode('create');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-medium text-gray-900">Gestion des CVs</h3>
        <button
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Nouveau CV
        </button>
      </div>

      <div className="mt-8 flow-root">
        <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
            <table className="min-w-full divide-y divide-gray-300">
              <thead>
                <tr>
                  <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Candidat</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Email</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Poste recherché</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Expérience</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Prétention</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date</th>
                  <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {cvs.map((cv) => (
                  <tr key={cv.id}>
                    <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">{cv.name}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.email}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.position}</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.experience} ans</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{cv.salary.toLocaleString()}€</td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      {new Date(cv.created_at).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                      <div className="flex space-x-2">
                        <button onClick={() => handleAction(cv, 'view')} className="text-blue-600 hover:text-blue-800">
                          <Eye className="h-5 w-5" />
                        </button>
                        <button onClick={() => handleAction(cv, 'edit')} className="text-amber-600 hover:text-amber-800">
                          <Pencil className="h-5 w-5" />
                        </button>
                        <button 
                          onClick={() => handleAction(cv, 'delete')} 
                          className="text-red-600 hover:text-red-800">
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={handleClose}
        title={
          modalMode === 'create' ? "Ajouter un nouveau CV" :
          modalMode === 'edit' ? "Modifier le CV" :
          modalMode === 'view' ? "Détails du CV" :
          "Supprimer le CV"
        }
      >
        {modalMode === 'delete' ? (
          <div className="space-y-4">
            <p className="text-sm text-gray-500">
              Êtes-vous sûr de vouloir supprimer ce CV ? Cette action est irréversible.
            </p>
            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                disabled={isLoading}
                className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
              >
                {isLoading ? 'Suppression...' : 'Supprimer'}
              </button>
            </div>
          </div>
        ) : (
          <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <label htmlFor="candidateName" className="block text-sm font-medium text-gray-700">
              Nom du candidat
            </label>
            <input
              type="text"
              name="name"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              defaultValue={selectedCV?.name}
              placeholder="ex: Marie Martin"
              readOnly={modalMode === 'view'}
            />
          </div>

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700">
              Email
            </label>
            <input
              type="email"
              name="email"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              defaultValue={selectedCV?.email}
              placeholder="ex: marie.martin@email.com"
              readOnly={modalMode === 'view'}
            />
          </div>

          <div>
            <label htmlFor="position" className="block text-sm font-medium text-gray-700">
              Poste recherché
            </label>
            <input
              type="text"
              name="position"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              defaultValue={selectedCV?.position}
              placeholder="ex: Développeur Frontend"
              readOnly={modalMode === 'view'}
            />
          </div>

          <div>
            <label htmlFor="experience" className="block text-sm font-medium text-gray-700">
              Années d'expérience
            </label>
            <input
              type="number"
              name="experience"
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              defaultValue={selectedCV?.experience}
              placeholder="ex: 5"
              readOnly={modalMode === 'view'}
            />
          </div>

          <div>
            <label htmlFor="salary" className="block text-sm font-medium text-gray-700">
              Prétention salariale
            </label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <input
                type="number"
                name="salary"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedCV?.salary}
                placeholder="ex: 45000"
                readOnly={modalMode === 'view'}
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <span className="text-gray-500 sm:text-sm">€</span>
              </div>
            </div>
            <p className="mt-1 text-sm text-gray-500">Salaire annuel brut souhaité en euros</p>
          </div>

          <div>
            <label htmlFor="cv" className="block text-sm font-medium text-gray-700">
              CV (PDF)
            </label>
            <input
              type="file"
              id="cv"
              accept=".pdf"
              disabled={modalMode === 'view'}
              className="mt-1 block w-full text-sm text-gray-500
                file:mr-4 file:py-2 file:px-4
                file:rounded-md file:border-0
                file:text-sm file:font-medium
                file:bg-indigo-50 file:text-indigo-700
                hover:file:bg-indigo-100"
            />
          </div>

          {modalMode !== 'view' && <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={handleClose}
              className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className={`inline-flex justify-center rounded-md border border-transparent px-4 py-2 text-sm font-medium text-white shadow-sm ${
                modalMode === 'edit' 
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-indigo-600 hover:bg-indigo-700'
              }`}
            >
              {isLoading 
                ? (modalMode === 'edit' ? "Modification..." : "Création...") 
                : (modalMode === 'edit' ? "Modifier" : "Ajouter le CV")
              }
            </button>
          </div>}
        </form>
        )}
      </Modal>
    </div>
  );
};

export default AdminCVs;