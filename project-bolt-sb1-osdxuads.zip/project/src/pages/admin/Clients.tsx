import React, { useState, useEffect } from 'react';
import { Plus, ChevronDown, ChevronRight, Pencil, Trash2, UserPlus } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Modal from '../../components/Modal';
import { getCompanies, createCompany, updateCompany, deleteCompany, createUser } from '../../lib/api';

interface Company {
  id: string;
  name: string;
  created_at: string;
  users: {
    id: string;
    email: string;
    role: string;
  }[];
}

const AdminClients: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create-company' | 'edit-company' | 'delete-company' | 'create-user' | 'edit-user' | 'delete-user'>('create-company');
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [selectedUser, setSelectedUser] = useState<Company['users'][0] | null>(null);
  const [expandedCompanies, setExpandedCompanies] = useState<number[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchCompanies();
  }, []);

  const fetchCompanies = async () => {
    try {
      const data = await getCompanies();
      setCompanies(data);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast.error('Failed to load companies');
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      if (modalMode === 'edit-company' && selectedCompany) {
        const name = formData.get('name') as string;
        await updateCompany(selectedCompany.id, name);
        toast.success('Company updated successfully');
      } else if (modalMode === 'create-company') {
        const name = formData.get('name') as string;
        await createCompany(name);
        toast.success('Company created successfully');
      } else if (modalMode === 'create-user' && selectedCompany) {
        const email = formData.get('email') as string;
        await createUser(selectedCompany.id, {
          email: email,
          role: 'client'
        });
        toast.success('User created successfully');
      }
      await fetchCompanies();
      handleClose();
    } catch (error) {
      console.error('Error saving company:', error);
      toast.error('Failed to save company');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedCompany) return;
    setIsLoading(true);

    try {
      await deleteCompany(selectedCompany.id);
      toast.success('Company deleted successfully');
      await fetchCompanies();
      handleClose();
    } catch (error) {
      console.error('Error deleting company:', error);
      toast.error('Failed to delete company');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleCompany = (companyId: number) => {
    setExpandedCompanies(prev =>
      prev.includes(companyId)
        ? prev.filter(id => id !== companyId)
        : [...prev, companyId]
    );
  };

  const handleAction = (
    mode: typeof modalMode,
    company: Company | null = null,
    user: Company['users'][0] | null = null
  ) => {
    setModalMode(mode);
    setSelectedCompany(company);
    setSelectedUser(user);
    setIsModalOpen(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setSelectedCompany(null);
    setSelectedUser(null);
    setModalMode('create-company');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-medium text-gray-900">Gestion des clients</h3>
        <button
          onClick={() => handleAction('create-company')}
          className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Nouvelle entreprise
        </button>
      </div>

      <div className="mt-8 space-y-4">
        {companies.map((company) => (
          <div key={company.id} className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => toggleCompany(company.id)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  {expandedCompanies.includes(company.id) ? (
                    <ChevronDown className="h-5 w-5" />
                  ) : (
                    <ChevronRight className="h-5 w-5" />
                  )}
                </button>
                <h4 className="text-lg font-medium text-gray-900">{company.name}</h4>
                <span className="text-sm text-gray-500">
                  ({company.users.length} utilisateur{company.users.length > 1 ? 's' : ''})
                </span>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleAction('create-user', company)}
                  className="text-indigo-600 hover:text-indigo-800"
                >
                  <UserPlus className="h-5 w-5" />
                </button>
                <button
                  onClick={() => handleAction('edit-company', company)}
                  className="text-amber-600 hover:text-amber-800"
                >
                  <Pencil className="h-5 w-5" />
                </button>
                <button
                  onClick={() => handleAction('delete-company', company)}
                  className="text-red-600 hover:text-red-800"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            {expandedCompanies.includes(company.id) && (
              <div className="border-t border-gray-200">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rôle</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {company.users.map((user) => (
                      <tr key={user.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.role}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleAction('edit-user', company, user)}
                              className="text-amber-600 hover:text-amber-800"
                            >
                              <Pencil className="h-5 w-5" />
                            </button>
                            <button
                              onClick={() => handleAction('delete-user', company, user)}
                              className="text-red-600 hover:text-red-800"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ))}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={handleClose}
        title={
          modalMode === 'create-company' ? "Ajouter une nouvelle entreprise" :
          modalMode === 'edit-company' ? "Modifier l'entreprise" :
          modalMode === 'delete-company' ? "Supprimer l'entreprise" :
          modalMode === 'create-user' ? "Ajouter un utilisateur" :
          modalMode === 'edit-user' ? "Modifier l'utilisateur" :
          "Supprimer l'utilisateur"
        }
      >
        {modalMode.includes('delete') ? (
          <div className="space-y-4">
            <p className="text-sm text-gray-500">
              {modalMode === 'delete-company' 
                ? "Êtes-vous sûr de vouloir supprimer cette entreprise et tous ses utilisateurs ?" 
                : "Êtes-vous sûr de vouloir supprimer cet utilisateur ?"
              } Cette action est irréversible.
            </p>
            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                onClick={handleDelete}
                disabled={isLoading}
                className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
              >
                {isLoading ? 'Suppression...' : 'Supprimer'}
              </button>
            </div>
          </div>
        ) : modalMode.includes('company') ? (
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Nom de l'entreprise
              </label>
              <input
                type="text"
                id="name"
                name="name"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedCompany?.name}
                placeholder="ex: Tech Solutions"
              />
            </div>
            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className={`inline-flex justify-center rounded-md border border-transparent px-4 py-2 text-sm font-medium text-white shadow-sm ${
                  modalMode === 'edit-company'
                    ? 'bg-amber-600 hover:bg-amber-700'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {isLoading 
                  ? (modalMode === 'edit-company' ? "Modification..." : "Création...") 
                  : (modalMode === 'edit-company' ? "Modifier" : "Créer")
                }
              </button>
            </div>
          </form>
        ) : (
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Email
              </label>
              <input
                type="email"
                name="email"
                id="email"
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                defaultValue={selectedUser?.email}
                placeholder="ex: jean.dupont@company.fr"
              />
            </div>
            <p className="text-sm text-gray-500">
              L'utilisateur sera créé avec le rôle "client" et recevra un email avec ses identifiants temporaires.
            </p>

            <div className="mt-5 sm:mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={handleClose}
                className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Annuler
              </button>
              <button
                type="submit"
                className={`inline-flex justify-center rounded-md border border-transparent px-4 py-2 text-sm font-medium text-white shadow-sm ${
                  modalMode === 'edit-user'
                    ? 'bg-amber-600 hover:bg-amber-700'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                {modalMode === 'edit-user' ? "Modifier" : "Créer"}
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default AdminClients;