import { supabase } from './supabase';
import { v4 as uuidv4 } from 'uuid';

export const uploadCV = async (file: File): Promise<string> => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${uuidv4()}.${fileExt}`;
  const filePath = `cvs/${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from('cvs')
    .upload(filePath, file);

  if (uploadError) {
    throw uploadError;
  }

  const { data: { publicUrl } } = supabase.storage
    .from('cvs')
    .getPublicUrl(filePath);

  return publicUrl;
};

// Companies
export const getCompanies = async () => {
  const { data, error } = await supabase
    .from('companies')
    .select('*, users(id, email, role)');
  
  if (error) throw error;
  return data;
};

export const createCompany = async (name: string) => {
  if (!name?.trim()) {
    throw new Error('Company name is required');
  }

  const { data, error } = await supabase
    .from('companies')
    .insert({ name })
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const updateCompany = async (id: string, name: string) => {
  if (!name?.trim()) {
    throw new Error('Company name is required');
  }

  const { data, error } = await supabase
    .from('companies')
    .update({ name })
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteCompany = async (id: string) => {
  const { error } = await supabase
    .from('companies')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

// Users
export const createUser = async (companyId: string, userData: {
  email: string;
  role: string;
}) => {
  const { data, error } = await supabase
    .rpc('create_client_user', {
      user_email: userData.email,
      company_id: companyId
    });

  if (error) throw error;
  return data;
};

// Jobs
export const getJobs = async () => {
  const { data, error } = await supabase
    .from('jobs')
    .select('*, companies(name)')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const getCompanyJobs = async (companyId: string) => {
  const { data, error } = await supabase
    .from('jobs')
    .select('*, companies(name)')
    .eq('company_id', companyId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const createJob = async (job: {
  title: string;
  company_id: string;
  location: string;
  salary: number;
  description: string;
}) => {
  if (!job.title?.trim() || !job.location?.trim() || !job.description?.trim()) {
    throw new Error('All required fields must be filled');
  }

  const { data, error } = await supabase
    .from('jobs')
    .insert(job)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const updateJob = async (id: string, job: {
  title: string;
  location: string;
  salary: number;
  description: string;
}) => {
  if (!job.title?.trim() || !job.location?.trim() || !job.description?.trim()) {
    throw new Error('All required fields must be filled');
  }

  const { data, error } = await supabase
    .from('jobs')
    .update(job)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteJob = async (id: string) => {
  const { error } = await supabase
    .from('jobs')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

// CVs
export const getCVs = async () => {
  const { data, error } = await supabase
    .from('cvs')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const createCV = async (cv: {
  name: string;
  email: string;
  position: string;
  experience: number;
  salary: number;
  file_url?: string;
}) => {
  if (!cv.name?.trim() || !cv.email?.trim() || !cv.position?.trim()) {
    throw new Error('All required fields must be filled');
  }
  
  if (!cv.file_url) {
    throw new Error('CV file is required');
  }

  const { data, error } = await supabase
    .from('cvs')
    .insert(cv)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const updateCV = async (id: string, cv: {
  name: string;
  email: string;
  position: string;
  experience: number;
  salary: number;
  file_url?: string;
}) => {
  if (!cv.name?.trim() || !cv.email?.trim() || !cv.position?.trim()) {
    throw new Error('All required fields must be filled');
  }
  
  if (!cv.file_url) {
    throw new Error('CV file is required');
  }

  const { data, error } = await supabase
    .from('cvs')
    .update(cv)
    .eq('id', id)
    .select()
    .single();
  
  if (error) throw error;
  return data;
};

export const deleteCV = async (id: string) => {
  const { error } = await supabase
    .from('cvs')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

// Job Applications
export const createJobApplication = async (data: {
  job_id: string;
  cv_id: string;
  notes?: string;
}) => {
  const { data: result, error } = await supabase
    .from('job_applications')
    .insert(data)
    .select()
    .single();

  if (error) throw error;
  return result;
};

export const updateJobApplication = async (id: string, data: {
  status: 'pending' | 'reviewing' | 'accepted' | 'rejected';
  notes?: string;
}) => {
  if (!['pending', 'reviewing', 'accepted', 'rejected'].includes(data.status)) {
    throw new Error('Invalid status');
  }
  
  // First update the status
  const { error: updateError } = await supabase
    .from('job_applications')
    .update(data)
    .eq('id', id);

  if (updateError) throw updateError;

  // Then fetch the updated record with all relations
  const { data: updated, error: fetchError } = await supabase
    .from('job_applications')
    .select(`
      *,
      jobs (
        id,
        title,
        companies (name)
      ),
      cvs (
        id,
        name,
        email,
        position,
        salary,
        experience,
        file_url
      )
    `)
    .eq('id', id)
    .select(`
      *,
      jobs (
        id,
        title,
        companies (name)
      ),
      cvs (
        id,
        name,
        email,
        position,
        salary,
        experience,
        file_url
      )
    `)
    .maybeSingle();

  if (fetchError) throw fetchError;
  if (!updated) throw new Error('Failed to update application');
  
  return updated;
};

export const deleteJobApplication = async (id: string) => {
  const { error } = await supabase
    .from('job_applications')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const getJobApplications = async (jobId?: string) => {
  let query = supabase
    .from('job_applications')
    .select(`
      *,
      jobs (
        id,
        title,
        companies (name)
      ),
      cvs (
        id,
        name,
        email,
        position,
        salary,
        experience,
        file_url
      )
    `)
    .order('created_at', { ascending: false });

  if (jobId) {
    query = query.eq('job_id', jobId);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data;
};